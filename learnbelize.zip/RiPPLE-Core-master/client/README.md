# RiPPLE Client
[Read the documentation at the wiki](https://github.com/hkhosrav/RiPPLE-Core/wiki/RiPPLE-Client)