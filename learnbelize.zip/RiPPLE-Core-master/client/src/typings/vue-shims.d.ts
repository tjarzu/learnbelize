declare module "*.vue" {
    import Vue from "vue";
    export default Vue;
}

declare module "vue-material" {
    const _: any;
    export default _;
}

declare module "vue-flatpickr-component" {
    const _: any;
    export default _;
}
