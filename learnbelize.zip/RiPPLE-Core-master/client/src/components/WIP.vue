<template>
    <div>
        <h1>
            404: Page not found.</h1>
    </div>
</template>

<script lang="ts">
import { Vue, Component } from "av-ts";

@Component()
export default class WIP extends Vue {
}
</script>
