<template>
    <div>
        <h1> Find Friends </h1>
    </div>
</template>

<style scoped>
    
</style>

<script lang="ts">
    import { Vue, Component } from "av-ts";

    @Component()
    export default class FriendView extends Vue { }
</script>
