# RiPPLE Server
The server component of the RiPPLE [Read the documentation at the wiki](https://github.com/hkhosrav/RiPPLE-Core/wiki)
